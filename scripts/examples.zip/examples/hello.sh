#!/bin/bash
hello()
{
    for i in seq 1 3 ; do 
        echo "Hello !"
    done
}

hello

