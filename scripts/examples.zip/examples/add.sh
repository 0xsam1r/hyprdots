#!/bin/bash
function add
{
    echo "$1 + $2 = $(($1 + $2))"
}

add 7 3 
